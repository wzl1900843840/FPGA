"""楼层演示状态机。只产生楼层意图，不直接写串口，也不假设真实轿厢速度。"""
from __future__ import annotations

from .protocol import floor_index

PERIOD = 2.0

# 1→5 上行、5 层停靠、5→1 下行、1 层停靠后循环
SEQUENCE = (
    (1, "S"), (2, "U"), (3, "U"), (4, "U"), (5, "S"),
    (4, "D"), (3, "D"), (2, "D"), (1, "S"),
)

STOPPED = "STOPPED"
RUNNING = "RUNNING"
PAUSED_USER = "PAUSED_USER"
PAUSED_ALARM = "PAUSED_ALARM"
PAUSED_LINK = "PAUSED_LINK"

STATE_TEXT = {
    STOPPED: "未运行",
    RUNNING: "运行中",
    PAUSED_USER: "已暂停",
    PAUSED_ALARM: "告警暂停",
    PAUSED_LINK: "链路暂停",
}


class DemoController:
    def __init__(self, clock=None, period: float = PERIOD):
        self.period = period
        self.state = STOPPED
        self.index = 0
        self.deadline = 0.0
        self.step = 0
        self.last_target: tuple[int, str] | None = None
        self.pending_target: tuple[int, str] | None = None
        self.paused_reason = ""

    # ------------------------------------------------------------------
    def start(self, now: float) -> tuple[int, str]:
        self.state = RUNNING
        self.index = 0
        self.step = 1
        self.deadline = now + self.period
        self.last_target = SEQUENCE[0]
        self.pending_target = SEQUENCE[0]
        self.paused_reason = ""
        return SEQUENCE[0]

    def tick(self, now: float) -> tuple[int, str] | None:
        """到点则给出下一个目标；忙时整周期顺延，不补发追赶。"""
        if self.state != RUNNING:
            return None
        if now < self.deadline:
            return None
        while self.deadline <= now:
            self.deadline += self.period
        self.index = (self.index + 1) % len(SEQUENCE)
        self.step += 1
        self.last_target = SEQUENCE[self.index]
        self.pending_target = self.last_target
        return self.last_target

    def pause(self, reason: str):
        if self.state == RUNNING:
            self.state = PAUSED_ALARM if reason == "alarm" else (
                PAUSED_LINK if reason == "link" else PAUSED_USER)
            self.paused_reason = reason

    def resume(self, now: float, current_floor: str, direction: str = "S") -> bool:
        """只从已回读楼层继续；楼层未知或不在 1～5 时要求重新开始。"""
        if self.state not in (PAUSED_USER, PAUSED_ALARM, PAUSED_LINK):
            return False
        room = floor_index(current_floor or "")
        if room is None:
            return False
        # 选一个"下一步会离开当前层"的位置，避免恢复后原地停一拍
        candidates = [
            i for i, (floor, _d) in enumerate(SEQUENCE)
            if floor == room and SEQUENCE[(i + 1) % len(SEQUENCE)][0] != room
        ] or [i for i, (floor, _d) in enumerate(SEQUENCE) if floor == room]
        self.index = candidates[-1] if direction == "D" else candidates[0]
        self.state = RUNNING
        self.deadline = now + self.period
        self.pending_target = None
        self.paused_reason = ""
        return True

    def stop(self):
        self.state = STOPPED
        self.index = 0
        self.step = 0
        self.pending_target = None
        self.deadline = 0.0

    def target_floor(self) -> str:
        if self.pending_target:
            return f"{self.pending_target[0]:02d}"
        return ""

    def applied(self, floor: str, direction: str):
        """设备回读到目标后清除待回读标记。"""
        if not self.pending_target:
            return
        room, want = self.pending_target
        if floor_index(floor) == room:
            self.pending_target = None

    # ------------------------------------------------------------------
    def snapshot(self, now: float) -> dict:
        return {
            "state": self.state,
            "text": STATE_TEXT.get(self.state, self.state),
            "step": self.step,
            "period": self.period,
            "next_in": max(0.0, self.deadline - now) if self.state == RUNNING else 0.0,
            "target": self.pending_target,
            "target_floor": f"{self.pending_target[0]:02d}" if self.pending_target else "",
            "running": self.state == RUNNING,
            "paused": self.state.startswith("PAUSED"),
        }
